package exception;

public class PrecioCeroException extends Exception{
	public PrecioCeroException(String msg) {
		super(msg);
	}
}
