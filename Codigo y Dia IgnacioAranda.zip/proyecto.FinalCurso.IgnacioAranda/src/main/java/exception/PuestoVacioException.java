package exception;

public class PuestoVacioException extends Exception{
	public PuestoVacioException(String msg) {
		super(msg);
	}
}
