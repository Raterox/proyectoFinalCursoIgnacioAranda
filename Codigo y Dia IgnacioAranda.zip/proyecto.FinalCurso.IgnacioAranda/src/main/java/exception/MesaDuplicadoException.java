package exception;

public class MesaDuplicadoException extends Exception{
	public MesaDuplicadoException(String msg) {
		super(msg);
	}
}
