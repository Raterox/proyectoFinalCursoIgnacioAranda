package exception;

public class ProductoDuplicadoException extends Exception{
	public ProductoDuplicadoException(String msg) {
		super(msg);
	}
}
