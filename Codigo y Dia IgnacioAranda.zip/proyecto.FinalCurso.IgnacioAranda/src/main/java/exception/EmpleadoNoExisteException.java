package exception;

public class EmpleadoNoExisteException extends Exception{
	public EmpleadoNoExisteException(String msg) {
		super(msg);
	}
}
