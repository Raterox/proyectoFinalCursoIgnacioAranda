package exception;

public class ContrasenaIncorrectaException extends Exception{
	public ContrasenaIncorrectaException(String msg) {
		super(msg);
		
	}
}
