package exception;

public class SimboloVacioException extends Exception{
	public SimboloVacioException(String msg) {
		super(msg);
	}
}
