package exception;

public class ApellidoVacioException extends Exception{
	public ApellidoVacioException(String msg) {
		super(msg);
	}
}
