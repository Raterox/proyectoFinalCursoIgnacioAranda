package exception;

public class SueldoVacioException extends Exception{
	public SueldoVacioException(String msg) {
		super(msg);
	}
}
