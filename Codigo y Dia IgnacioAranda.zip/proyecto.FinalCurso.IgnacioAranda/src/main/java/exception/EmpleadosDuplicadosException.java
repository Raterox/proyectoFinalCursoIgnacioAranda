package exception;

public class EmpleadosDuplicadosException extends Exception{
	public EmpleadosDuplicadosException(String msg) {
		super(msg);
	}
}
