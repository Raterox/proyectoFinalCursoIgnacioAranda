package exception;

public class ZonaDuplicadoException extends Exception{
	public ZonaDuplicadoException(String msg) {
		super(msg);
	}
}
