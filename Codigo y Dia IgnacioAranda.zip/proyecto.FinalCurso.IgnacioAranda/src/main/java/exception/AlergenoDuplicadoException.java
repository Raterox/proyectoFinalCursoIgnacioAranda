package exception;

public class AlergenoDuplicadoException extends Exception {
	public AlergenoDuplicadoException(String msg) {
		super(msg);
	}
}
