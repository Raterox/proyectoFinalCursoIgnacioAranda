package exception;

public class ContrasenaVaciaException extends Exception {
	public ContrasenaVaciaException(String msg) {
		super(msg);
	}
}
