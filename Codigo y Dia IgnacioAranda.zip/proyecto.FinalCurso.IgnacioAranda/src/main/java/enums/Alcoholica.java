package enums;

public enum Alcoholica {
	SI,
	NO
}
