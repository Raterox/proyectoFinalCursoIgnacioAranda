package enums;

public enum TipoProducto {
	PRINCIPAL,
	ENTRANTE,
	POSTRE,
	BEBIDA
}
