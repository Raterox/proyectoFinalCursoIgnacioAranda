package enums;

public enum Puesto {
	BECARIO,
	COCINERO,
	BARRA,
	CAMARERO,
	ENCARGADO,
	ADMINISTRADOR
	
}
